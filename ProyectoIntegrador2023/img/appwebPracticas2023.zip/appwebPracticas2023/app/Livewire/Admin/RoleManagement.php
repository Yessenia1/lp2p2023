<?php

namespace App\Livewire\Admin;

use Livewire\Component;

class RoleManagement extends Component
{
    public function render()
    {
        return view('livewire.admin.role-management');
    }
}
